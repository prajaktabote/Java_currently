package com.ex.Service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.ex.entity.Employee;
import com.ex.repository.EmployeeRepository;

@Service
public class ServiceClass {

	@Autowired
	EmployeeRepository eRes;
	
	public List<Employee> getAllEmp()
	{
		return eRes.findAll();
	}
	
public String saveEmp(Employee e) 	
	{
		eRes.save(e);
		return "1 employee Record added successfully..!";
	}
	
	public Employee getEmpById(Long id) {
		return eRes.findById(id)   .orElse(null);
	}
	
	public String deleteEmp(long id) {
	eRes.deleteById(id);
	return "1 record deleted successfully..!";
	
	}
	public String update(Long id,Employee emp)
	{
		Employee s2=eRes.findById(id).orElse(null);
		
		if(emp!=null)
		{
			if(emp.getName()!=null)
			{
				s2.setName(emp.getName());
			}
			if(emp.getDepartment()!=null)
					
			{
				s2.setDepartment(emp.getDepartment());
			}
			if(emp.getRole()!=null)
			{
				s2.setRole(emp.getRole());
			}
			if(emp.getEmail()!=null)
			{
				s2.setEmail(emp.getEmail());
			}
			if(emp.getSalary()!=0.0)
			{
				s2.setSalary(emp.getSalary());
			}
		}
		eRes.save(s2);
		return "Updated successfully";
	}
	
	public List<Employee> findByName(String name){	
		return eRes.findByName(name);
	}
	
	public List<Employee> findByRole(String role){
		return eRes.findByRole(role);
	}
	
	public List<Employee> findByDepartment(String dept){
		return eRes.findByDepartment(dept);
	}
	
	public List<Employee> findBySalary(double salary){
		return eRes.findBySalary(salary);
	}
	
	
	
}
