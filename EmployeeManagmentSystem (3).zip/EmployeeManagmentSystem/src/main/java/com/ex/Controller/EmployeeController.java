package com.ex.Controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ex.entity.Employee;
import com.ex.repository.EmployeeRepository;

@RestController
@RequestMapping("/api/employees")
@CrossOrigin(origins="http://localhost:3000")
public class EmployeeController {
	@Autowired
	 private EmployeeRepository employeeRepository;
	 
	 @GetMapping("/all")
	 public List<Employee> getAllEmployees(){
		 return employeeRepository.findAll();
	 	}
	 @GetMapping("/empdata/{id}")
	 public Employee getEmployeeById(@PathVariable Long id) {
		 return employeeRepository.findById(id).orElse(null);
	 }

}