package com.ex.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ex.Service.ServiceClass;
import com.ex.entity.Employee;

@RestController
@RequestMapping("/api/admin")
@CrossOrigin(origins="http://localhost:3000")//allow react (running on port 3000)
public class AdminController {

	@Autowired
	ServiceClass serv;
	
	@PostMapping("/saveEmp")
	public String saveEmp(@RequestBody Employee e) 
	{
		return serv.saveEmp(e);
	}
	
	
	@GetMapping("/getAllEmp")
	public List<Employee> getAllEmp()
	{
		return serv.getAllEmp();
	}
	
	
	@GetMapping("/getByid/{id}")
	public Employee getEmpById(@PathVariable("id") Long id) {
		return serv.getEmpById(id);
	}
	
	
	@DeleteMapping("/deleteById/{id}")
	public String deleteEmp(@PathVariable("id") long id) {
		serv.deleteEmp(id);
		return "1 record deleted successfully..!";
	}
	
	
	@PutMapping("/updateEmp/{id}")
	public String update(@PathVariable("id")Long id,@RequestBody Employee emp)
	{
		return serv.update(id,emp);
	}

	
	@GetMapping("/getByNm/{name}")
	public List<Employee> findByName(@PathVariable("name") String name){	
		return serv.findByName(name);	
	}
	
	@GetMapping("/getByrl/{role}")
	public List<Employee> findByRole(@PathVariable("role")String role){
		return serv.findByRole(role);
	}
	
	
	@GetMapping("/getBydpt/{dept}")
	public List<Employee> findByDepartment(@PathVariable("dept") String dept){
		return serv.findByDepartment(dept);
	}
	
	@GetMapping("/getbysal/{salary}")
	public List<Employee> findBySalary(@PathVariable("salary") double salary){
		return serv.findBySalary(salary);
	}
	
}
