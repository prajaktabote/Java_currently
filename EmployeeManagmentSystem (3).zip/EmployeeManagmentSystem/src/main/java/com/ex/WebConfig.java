package com.ex;

public class WebConfig {

}
