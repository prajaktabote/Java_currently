package com.ex;


public class SecurityConfig {

}
